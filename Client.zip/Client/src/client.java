import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.io.*;

public class client {
    static JFrame frame = new JFrame("client");
    static JPanel panel = new JPanel();
    static JTextArea chatResult = new JTextArea();
    static JTextField chatWrite = new JTextField();
    static JButton button = new JButton();
    static Socket s;
    static OutputStream out;
    static InputStream in;
    static byte[] bufferIn, bufferOut;
    static Thread receiveMessage = new Thread(new listener());

    public static void main(String Args[]) {
        window();
    }

    public static void window(){
        frame.setVisible(true);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setSize(900, 550);
        panel.setLayout(new BorderLayout());

        frame.add(panel);
        panel.add(button, BorderLayout.CENTER);

        button.setText("Connect to server");
        button.setFont(new Font("TimesRoman", Font.PLAIN, 100));
        button.setHorizontalAlignment(SwingConstants.CENTER);
        button.setVerticalAlignment(SwingConstants.CENTER);
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    s = new Socket("localhost", 7777);

                    in = s.getInputStream();
                    out = s.getOutputStream();

                    System.out.println("Connected to a server");
                    chatroom();

                    receiveMessage.start();
                }

                catch(Exception q) {
                    button.setText("Server is offline");
                }
            }
        });
    }

    public static void chatroom(){
        panel.remove(button);

        panel.add(chatWrite, BorderLayout.PAGE_END);
        panel.add(chatResult, BorderLayout.CENTER);

        chatResult.setEditable(false);

        chatWrite.setText("write here...");
        chatWrite.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                chatWrite.setText("");
            }
        });

        chatWrite.addKeyListener(new KeyListener() {
            public void keyTyped(KeyEvent e) {}

            public void keyPressed(KeyEvent e) {}

            public void keyReleased(KeyEvent e) {
                if(chatWrite.getText().length() > 0 && chatWrite.getText().length() < 100){
                    if(e.getKeyCode() == KeyEvent.VK_ENTER){
                        try{
                            chatResult.append("Client: " + chatWrite.getText() + "\n");

                            bufferOut = new byte[1000];

                            bufferOut = chatWrite.getText().getBytes();
                            out.write(bufferOut); // skickar ut
                            System.out.println("signal givet");

                            chatWrite.setText(""); // reset
                        }

                        catch(Exception r){}
                    }
                }

                else{
                    chatWrite.setText("you need to write 1 - 100 characters");

                    chatWrite.addMouseListener(new MouseAdapter() {
                        public void mouseClicked(MouseEvent e) {
                            chatWrite.setText("");
                        }
                    });
                }
            }
        });
    }

    public static class listener implements Runnable{
        public void run() {
            try{
                while(true){
                    bufferIn = new byte[1000];

                    in.read(bufferIn); // får in
                    System.out.println("signal taget");
                    String response = new String(bufferIn); // översätter
                    chatResult.append("Server: " + response + "\n");
                }
            }

            catch(Exception e){
                e.printStackTrace();
            }
        }
    }
}